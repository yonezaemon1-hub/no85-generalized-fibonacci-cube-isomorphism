from itertools import combinations
from random import Random
from collections import Counter
import networkx as nx
from verify import words, patterns, mask, terms, comps, contains
rng=Random(85)
counts=Counter()
# Direct verification of the geometric hypotheses used by the extension proof.
for d in range(4,9):
    for m in range(1,min(4,d-2)+1):
        for trial in range(20):
            forbidden=[]
            for _ in range(m):
                fixed=rng.sample(range(d),rng.randint(m+2,d)); M=sum(1<<j for j in fixed); B=sum((rng.randrange(2)<<j) for j in fixed); forbidden.append((M,B))
            G={x for x in range(1<<d) if not any(x&M==B for M,B in forbidden)}
            assert len(comps(G,d))==1
            for j in range(d):
                E={x for x in G if not x>>j&1 and x^(1<<j) in G}
                assert len(comps(E,d))==1
                counts['direction_checks']+=1
            counts['random_cube_unions']+=1

def graph(d,S):
    G=nx.Graph(); G.add_nodes_from(S)
    G.add_edges_from((x,x^(1<<i)) for x in S for i in range(d) if x^(1<<i) in S)
    return G

def direct(k,r,f):
    d=k+r; S={x for x in range(1<<d) if f in format(x,f'0{d}b')}; return S,graph(d,set(range(1<<d))-S)

def ambient(d,S):
    G=nx.Graph();
    for j in range(d):
        G.add_node(('p',j),color='pair')
        for b in (0,1):
            G.add_node(('l',j,b),color='literal'); G.add_edge(('p',j),('l',j,b))
    for x in S:
        G.add_node(('x',x),color='point')
        for j in range(d): G.add_edge(('x',x),('l',j,(x>>(d-1-j))&1))
    return G

def compressed(f,r):
    d=len(f)+r; p=patterns(f,r); A={i for i in range(d) if any(t[i]=='*' for t in p)}; C=nx.Graph(); C.add_nodes_from(range(r+1))
    for i,j in combinations(range(r+1),2):
        M=[h for h,(a,b) in enumerate(zip(p[i],p[j])) if a!='*' and b!='*' and a!=b]
        if len(M)<=1: C.add_edge(i,j); A.update(M)
    A=sorted(A); groups=list(nx.connected_components(C)); G=nx.Graph()
    for j in A:
        G.add_node(('p',j),color='pair')
        for b in (0,1): G.add_node(('l',j,b),color='literal'); G.add_edge(('p',j),('l',j,b))
    for i,group in enumerate(groups):
        G.add_node(('c',i),color='component')
        T=[(s,''.join(t[j] for j in A)) for s,t in terms(f,r) if any(contains(p[h],t) for h in group)]
        # Encode only nonzero Fourier coefficients; omission denotes zero.
        for mm in range(1<<len(A)):
            I=[j for j in range(len(A)) if mm>>j&1]
            W=sum(s*2**t.count('*')*(-1)**sum(int(t[j]) for j in I) for s,t in T if all(t[j]!='*' for j in I))
            if not W: continue
            for b in range(1<<len(I)):
                e=('w',i,mm,b); G.add_node(e,color='w:'+str(W*(-1)**b.bit_count())); G.add_edge(e,('c',i))
                for h,j in enumerate(I): G.add_edge(e,('l',A[j],b>>h&1))
    H=Counter()
    for j in set(range(d))-set(A):
        B=frozenset(i for i,g in enumerate(groups) if p[min(g)][j]=='1'); Bc=frozenset(range(len(groups)))-B
        H[min((B,Bc),key=lambda x:tuple(sorted(x)))]+=1
    for n,(B,v) in enumerate(H.items()):
        for b,T in enumerate((B,frozenset(range(len(groups)))-B)):
            e=('h',n,b); G.add_node(e,color='h:'+str(v))
            for i in T:G.add_edge(e,('c',i))
    return G

def iso(A,B):
    if nx.weisfeiler_lehman_graph_hash(A,node_attr='color')!=nx.weisfeiler_lehman_graph_hash(B,node_attr='color'):return False
    return nx.is_isomorphic(A,B,node_match=lambda x,y:x['color']==y['color'])
# Stratified pairs, including trivial isomorphisms, known nontrivial cases and random comparisons.
for k,r in [(4,1),(5,2)]:
    W=list(words(k)); pairs=[(f,f[::-1]) for f in rng.sample(W,4)]+[(f,f.translate(str.maketrans('01','10'))) for f in rng.sample(W,4)]+[(rng.choice(W),rng.choice(W)) for _ in range(12)]
    if r==1:pairs += [('0010','0100'),('0011','0111')]
    for f,g in pairs:
        S,G=direct(k,r,f); T,H=direct(k,r,g); a=iso(ambient(k+r,S),ambient(k+r,T)); b=iso(compressed(f,r),compressed(g,r))
        assert a==b,(k,r,f,g,a,b)
        # Exact residual graph GI, with a WL hash rejection filter.
        if nx.weisfeiler_lehman_graph_hash(G)!=nx.weisfeiler_lehman_graph_hash(H):c=False
        else:c=nx.is_isomorphic(G,H)
        assert a==c,(k,r,f,g,a,c)
        counts['graph_pairs']+=1; counts['isomorphic' if a else 'nonisomorphic']+=1
print(dict(counts)); print('PASS')
