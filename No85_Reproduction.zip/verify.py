from itertools import product, combinations
from collections import Counter

def words(k): return (''.join(x) for x in product('01', repeat=k))
def patterns(f,r): return ['*'*i+f+'*'*(r-i) for i in range(r+1)]
def meet(x,y): return ''.join(b if a=='*' else a for a,b in zip(x,y))
def contains(p,x): return all(a=='*' or a==b for a,b in zip(p,x))
def terms(f,r):
    p=patterns(f,r); P={h for h in range(1,r+1) if f[:-h]==f[h:]}; D=P-{a+b for a in P for b in P}
    return [(1,x) for x in p]+[(-1,meet(p[i],p[i+h])) for h in sorted(D) for i in range(r+1-h)]
def mask(p): return int(p.replace('0','1').replace('*','0'),2),int(p.replace('*','0'),2)
def comps(S,d):
    rest=set(S); out=[]
    while rest:
        stack=[rest.pop()]; comp=set(stack)
        while stack:
            x=stack.pop()
            for j in range(d):
                y=x^(1<<j)
                if y in rest: rest.remove(y); comp.add(y); stack.append(y)
        out.append(comp)
    return out

def delta(f): return ''.join(str(int(a!=b)) for a,b in zip(f,f[1:]))
def ab(s,r): return (s[:r-1],s[len(s)-r+1:],tuple(sorted(Counter(s[i:i+r] for i in range(len(s)-r+1)).items())))
def abcanon(f,r):
    s=delta(f); return min(ab(s,r),ab(s[::-1],r))
def colcanon(f,r):
    p=patterns(f,r)
    def norm(col): return min(col,col.translate(str.maketrans('01','10')))
    def code(rows): return tuple(sorted(norm(''.join(c)) for c in zip(*rows)))
    return min(code(p),code(p[::-1]))

def check():
    counts=Counter()
    for r in range(1,5):
        for k in range(r+3,9):
            forward={}; reverse={}
            for f in words(k):
                T=terms(f,r); d=k+r; S=set(); MT=[(s,*mask(p)) for s,p in T]
                for x in range(1<<d):
                    b=f in format(x,f'0{d}b'); v=sum(s for s,m,t in MT if x&m==t); assert v==b,(f,r,x,v); counts['indicator_points']+=1
                    if b:S.add(x)
                assert len(S)==sum(s*2**p.count('*') for s,p in T)
                C=comps(S,d); A={j for x in S for j in range(d) if x^(1<<(d-1-j)) in S}
                assert len(A)+len(C)<=3*r+1
                p=patterns(f,r); E={j for j in range(d) if any(t[j]=='*' for t in p)}; adj=[set() for t in p]
                for i,j in combinations(range(len(p)),2):
                    M=[h for h,(a,b) in enumerate(zip(p[i],p[j])) if a!='*' and b!='*' and a!=b]
                    if len(M)<=1: adj[i].add(j); adj[j].add(i); E.update(M)
                assert E==A
                seen=set(); groups=[]
                for i in range(len(p)):
                    if i in seen: continue
                    todo=[i]; seen.add(i); group=[]
                    while todo:
                        j=todo.pop(); group.append(j)
                        for h in adj[j]-seen: seen.add(h); todo.append(h)
                    groups.append(group)
                assert len(groups)==len(C)
                counts['words']+=1
                if all(sum(a!=b for a,b in zip(f[:-h],f[h:]))>=2 for h in range(1,r+1)):
                    u,v=abcanon(f,r),colcanon(f,r)
                    assert forward.setdefault(u,v)==v and reverse.setdefault(v,u)==u
                    counts['abelian_words']+=1
                if r<=3 and int(f,2)%17==0:
                    aa=sorted(A); SS=[format(x,f'0{d}b') for x in S]
                    for group in groups:
                        U={''.join(x[j] for j in aa) for x in SS if any(contains(p[i],x) for i in group)}
                        TT=[(s,''.join(t[j] for j in aa)) for s,t in T if any(contains(p[i],t) for i in group)]
                        for mm in range(1<<len(aa)):
                            I=[j for j in range(len(aa)) if mm>>j&1]
                            direct=sum((-1)**sum(int(x[j]) for j in I) for x in U)
                            symbolic=sum(s*2**t.count('*')*(-1)**sum(int(t[j]) for j in I) for s,t in TT if all(t[j]!='*' for j in I))
                            assert direct==symbolic,(f,r,group,I,direct,symbolic)
                            counts['fourier_coefficients']+=1
    for r in range(2,101):
        f='0'*(r+1)+'1'*r+'0'; g='0'*r+'1'*(r+1)+'0'
        assert abcanon(f,r)==abcanon(g,r)
        for w in (f,g): assert all(sum(a!=b for a,b in zip(w[:-h],w[h:]))>=2 for h in range(1,r+1))
        assert g not in (f,f[::-1],f.translate(str.maketrans('01','10')),f[::-1].translate(str.maketrans('01','10')))
        counts['sharp_family_pairs']+=1
    print(dict(counts)); print('PASS')
if __name__=='__main__': check()
